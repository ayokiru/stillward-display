Stillward Display pointer template

Seventeen pointers, one per role, named after the role, and scheme.json naming the set.
Draw over them in any SVG editor, keep the file names, and choose the folder's files or
this zip on the Pointer page with Choose files.

- viewBox 0 0 32 32; data-hotspot="x y" on the root is the point that points.
- Wait and AppStarting turn: data-spin="x y" on the root, id="spin" on the turning part.
- Frames of your own: id="frame-0", id="frame-1"..., each with data-ms.
- Real colours, shapes only: text and pictures inside a drawing are not drawn.
- stillward-display.exe --check <this folder> says what the program would take.

More: https://stillwarddisplay.com/creators/pointers/
